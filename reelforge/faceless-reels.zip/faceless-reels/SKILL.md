---
name: faceless-reels
description: Make faceless Instagram Reels, YouTube Shorts and TikToks from one idea. Acts as an orchestrator - picks the best video format (character story, collage explainer, whiteboard, top facts, what-if 3D, history doc, scary story, motivation, money and data, how-to), image style, length and single reel vs series - writes 3 scripts to choose from, then renders vertical mp4s with AI images, voiceover, burned-in captions and motion. Free tools, no API key. Use when the user says "make a reel", "faceless video", "shorts about X", "reel series", "turn this idea into a video".
---

# Faceless Reels

You are the producer. The user brings an idea; you decide how to make it, write it, and render it.
`formats.yaml` (next to this file) is the menu: every format, its rules and the styles that fit it.

## Setup check (once)

Run `ffmpeg -version` and `python3 -c "import PIL, edge_tts"`.
If something is missing, tell the user the one command: `brew install ffmpeg` (macOS) or `sudo apt install ffmpeg`, and `pip3 install pillow edge-tts`.

## 1. Orchestrate

Read `formats.yaml`. From the idea and anything the user said (audience, tone, language, platform), pick:
- **format**: the one whose `when` fits best.
- **style**: one of that format's `styles` unless the user's idea clearly wants another.
- **length**: from `lengths`; the shortest that does the idea justice. Default 30.
- **episodes**: 1, or 2 to `max_episodes` only if the idea splits naturally or the user asked for a series.

Anything the user already chose wins. Never override it.
Tell the user your pick in one line with a short reason, e.g. `Plan: What-if 3D short · 3D Realistic Render · 30 s · single reel - a science what-if lands best as a 3D walkthrough.`
Don't wait for approval; go straight to scripts. The user can redirect at any point.

## 2. Three scripts

Write 3 options, each a clearly different angle, all following the format's `script` rules.
- About 2.4 spoken words per second of length (30 s = about 72 words).
- Hook in the first sentence. No filler. Strong ending: loop, twist or call to follow.
- Narration only: no stage directions, emojis or hashtags.
- Series: every episode its own reel, each ending on a cliffhanger into the next.

Show each option as: title, one-line pitch, the full narration. Ask which one to make (they may edit it).

## 3. Plan the scenes

For the chosen script write `plan.json` in the working folder:

```json
{"style": "<the style's prompt text from formats.yaml>",
 "character": "<recurring main character or visual motif: looks, clothes, colours>",
 "episodes": [{"title": "...", "caption": "hook line, 1-2 lines, then 5 hashtags",
   "scenes": [{"narration": "...", "visual": "..."}]}]}
```

- One scene per 3-6 seconds (30 s is about 7 scenes). Narration across scenes, in order, is the whole script.
- `visual`: one vertical 9:16 shot. Subject, action, setting, camera angle, mood. Follow the format's `visuals` rules. Never ask for text or letters in the image.

## 4. Render

```sh
python3 <this skill's folder>/render.py plan.json --out reels
```
Optional `--voice` with any Edge TTS voice (`edge-tts --list-voices`; e.g. `en-IN-PrabhatNeural`, `hi-IN-MadhurNeural` for Hindi).
Without a `POLLINATIONS_KEY` env var, free images are limited to 1 every 45 s, so a 30 s reel takes about 6 minutes. Tell the user that before starting, and run it in the background if you can.

## 5. Hand over

List the mp4 and caption .txt paths. Offer one quick fix pass, such as regenerating a weak scene (edit that scene in `plan.json` and re-run).
