#!/usr/bin/env python3
"""Render faceless reels from a plan JSON. Free tools only: Pollinations images, Edge TTS voice, ffmpeg.

Usage: python3 render.py plan.json [--out reels] [--voice en-US-AndrewNeural]

plan.json:
{"style": "image style prompt text", "character": "recurring character or visual motif",
 "episodes": [{"title": "...", "caption": "post caption + hashtags",
               "scenes": [{"narration": "spoken line", "visual": "image prompt"}]}]}
"""
import argparse, asyncio, json, os, re, subprocess, sys, textwrap, time, urllib.error, urllib.parse, urllib.request

FONTS = ["/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "C:/Windows/Fonts/arialbd.ttf"]


def retry(fn, tries=5):
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            if i == tries - 1:
                raise
            limited = isinstance(e, urllib.error.HTTPError) and e.code in (402, 429)
            if limited:
                print("  free image limit hit, waiting 46 s (set POLLINATIONS_KEY to skip)", flush=True)
            time.sleep(46 if limited else 3 * (i + 1))


def image(prompt, seed, path):
    url = ("https://image.pollinations.ai/prompt/" + urllib.parse.quote(prompt[:1500]) +
           f"?width=1080&height=1920&nologo=true&seed={seed}&model=flux")
    key = os.environ.get("POLLINATIONS_KEY")
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {key}"} if key else {})
    data = retry(lambda: urllib.request.urlopen(req, timeout=180).read())
    open(path, "wb").write(data)


def tts(text, voice, path):
    import edge_tts
    retry(lambda: asyncio.run(edge_tts.Communicate(text, voice).save(path)))


def caption_chunks(text, dur, words=3):
    """Split narration into short on-screen chunks timed by character length. Returns [(chunk, start, end)]."""
    w = text.split()
    chunks = [" ".join(w[i:i + words]) for i in range(0, len(w), words)]
    total = sum(len(c) + 1 for c in chunks) or 1
    out, t = [], 0.0
    for c in chunks:
        d = dur * (len(c) + 1) / total
        out.append((c, round(t, 3), round(t + d, 3)))
        t += d
    return out


def caption_png(text, path):
    from PIL import Image, ImageDraw, ImageFont
    font = next((ImageFont.truetype(f, 76) for f in FONTS if os.path.exists(f)), None) or ImageFont.load_default(76)
    img = Image.new("RGBA", (1080, 320), (0, 0, 0, 0))
    ImageDraw.Draw(img).multiline_text((540, 160), "\n".join(textwrap.wrap(text.upper(), 18)), font=font, anchor="mm",
                                       align="center", fill="white", stroke_width=7, stroke_fill="black", spacing=10)
    img.save(path)


def ffmpeg(*args):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *args], check=True)


def duration(path):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]))


def scene_clip(plan, scene, seed, voice, d, i):
    audio, img, clip = f"{d}/s{i}.mp3", f"{d}/s{i}.jpg", f"{d}/s{i}.mp4"
    tts(scene["narration"], voice, audio)
    image(f"{scene['visual']}. Main character: {plan.get('character', '')}. {plan.get('style', '')}. "
          "Vertical 9:16 composition, no text.", seed, img)
    dur = duration(audio) + 0.3
    caps = caption_chunks(scene["narration"], dur - 0.3)
    zoom = "min(zoom+0.0007,1.2)" if i % 2 == 0 else "if(eq(on,0),1.2,max(zoom-0.0007,1))"  # alternate push-in / pull-out
    inputs = ["-i", img, "-i", audio]
    chain = [f"[0]scale=1620:2880:force_original_aspect_ratio=increase,crop=1620:2880,"
             f"zoompan=z='{zoom}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={int(dur * 30) + 1}:s=1080x1920:fps=30[v0]"]
    for k, (text, a, b) in enumerate(caps):
        png = f"{d}/s{i}c{k}.png"
        caption_png(text, png)
        inputs += ["-i", png]
        chain.append(f"[v{k}][{k + 2}]overlay=0:1250:enable='between(t,{a},{b})'[v{k + 1}]")
    ffmpeg(*inputs, "-filter_complex", ";".join(chain), "-map", f"[v{len(caps)}]", "-map", "1:a", "-af", "apad",
           "-t", f"{dur:.3f}", "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-ar", "44100", "-ac", "2", clip)
    return clip


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("plan")
    ap.add_argument("--out", default="reels")
    ap.add_argument("--voice", default="en-US-AndrewNeural", help="any Edge TTS voice, list with: edge-tts --list-voices")
    a = ap.parse_args()
    plan = json.load(open(a.plan))
    assert plan.get("episodes") and all(e.get("scenes") for e in plan["episodes"]), "plan needs episodes with scenes"
    seed = sum(map(ord, plan.get("character", ""))) % 1_000_000  # same seed every scene keeps the look consistent
    for e, ep in enumerate(plan["episodes"], 1):
        d = os.path.abspath(f"{a.out}/.work/ep{e}")
        os.makedirs(d, exist_ok=True)
        clips = []
        for i, sc in enumerate(ep["scenes"]):
            print(f"Episode {e}: scene {i + 1}/{len(ep['scenes'])}", flush=True)
            clips.append(scene_clip(plan, sc, seed, a.voice, d, i))
        open(f"{d}/list.txt", "w").write("".join(f"file '{c}'\n" for c in clips))
        name = re.sub(r"[^a-z0-9]+", "-", ep.get("title", "reel").lower()).strip("-")[:40] or "reel"
        final = f"{a.out}/{e:02d}-{name}.mp4"
        ffmpeg("-f", "concat", "-safe", "0", "-i", f"{d}/list.txt", "-c", "copy", "-movflags", "+faststart", final)
        open(final[:-4] + ".txt", "w").write(f"{ep.get('title', '')}\n\n{ep.get('caption', '')}\n")
        print("Done:", final, flush=True)


if __name__ == "__main__":
    sys.exit(main())
